/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.Client;
/*    */ import de.upb.swtpra1819interface.models.GameState;
/*    */ import de.upb.swtpra1819interface.models.Tile;
/*    */ import de.upb.swtpra1819interface.models.TileOnPosition;
/*    */ import java.util.Collection;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GameDataResponse
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 499;
/*    */   private Collection<TileOnPosition> board;
/*    */   private Client currentClient;
/*    */   private Collection<Tile> ownTiles;
/*    */   private GameState gameState;
/*    */   
/*    */   public GameDataResponse(Collection<TileOnPosition> board, Client currentClient, Collection<Tile> ownTiles, GameState gameState)
/*    */   {
/* 32 */     super(499);
/* 33 */     this.board = board;
/* 34 */     this.currentClient = currentClient;
/* 35 */     this.ownTiles = ownTiles;
/* 36 */     this.gameState = gameState;
/*    */   }
/*    */   
/*    */   public Collection<TileOnPosition> getBoard() {
/* 40 */     return this.board;
/*    */   }
/*    */   
/*    */   public Client getCurrentClient() {
/* 44 */     return this.currentClient;
/*    */   }
/*    */   
/*    */   public Collection<Tile> getOwnTiles() {
/* 48 */     return this.ownTiles;
/*    */   }
/*    */   
/*    */   public GameState getGameState() {
/* 52 */     return this.gameState;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 57 */     if (this == o) {
/* 58 */       return true;
/*    */     }
/* 60 */     if (!(o instanceof GameDataResponse)) {
/* 61 */       return false;
/*    */     }
/* 63 */     GameDataResponse that = (GameDataResponse)o;
/* 64 */     return (getGameState() == that.getGameState()) && 
/* 65 */       (Objects.equals(getBoard(), that.getBoard())) && 
/* 66 */       (Objects.equals(getCurrentClient(), that.getCurrentClient())) && 
/* 67 */       (Objects.equals(getOwnTiles(), that.getOwnTiles()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\GameDataResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */