/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.Game;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GameJoinAccepted
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 303;
/*    */   private Game game;
/*    */   
/*    */   public GameJoinAccepted(Game game)
/*    */   {
/* 20 */     super(303);
/* 21 */     this.game = game;
/*    */   }
/*    */   
/*    */   public Game getGame() {
/* 25 */     return this.game;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 30 */     if (this == o) {
/* 31 */       return true;
/*    */     }
/* 33 */     if (!(o instanceof GameJoinAccepted)) {
/* 34 */       return false;
/*    */     }
/* 36 */     GameJoinAccepted that = (GameJoinAccepted)o;
/* 37 */     return Objects.equals(this.game, that.game);
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\GameJoinAccepted.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */