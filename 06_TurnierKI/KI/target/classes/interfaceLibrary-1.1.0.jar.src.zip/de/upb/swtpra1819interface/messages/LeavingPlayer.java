/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.Client;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LeavingPlayer
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 406;
/*    */   private Client client;
/*    */   
/*    */   public LeavingPlayer(Client client)
/*    */   {
/* 20 */     super(406);
/* 21 */     this.client = client;
/*    */   }
/*    */   
/*    */   public Client getClient() {
/* 25 */     return this.client;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 30 */     if (this == o) {
/* 31 */       return true;
/*    */     }
/* 33 */     if (!(o instanceof LeavingPlayer)) {
/* 34 */       return false;
/*    */     }
/* 36 */     LeavingPlayer that = (LeavingPlayer)o;
/* 37 */     return Objects.equals(getClient(), that.getClient());
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\LeavingPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */