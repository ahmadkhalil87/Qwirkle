/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageSend
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 306;
/*    */   private String message;
/*    */   
/*    */   public MessageSend(String message)
/*    */   {
/* 19 */     super(306);
/* 20 */     this.message = message;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 24 */     return this.message;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 29 */     if (this == o) {
/* 30 */       return true;
/*    */     }
/* 32 */     if (!(o instanceof MessageSend)) {
/* 33 */       return false;
/*    */     }
/* 35 */     MessageSend that = (MessageSend)o;
/* 36 */     return Objects.equals(getMessage(), that.getMessage());
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\MessageSend.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */