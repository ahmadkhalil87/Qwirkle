/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MoveValid
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 415;
/*    */   private boolean validation;
/*    */   private String message;
/*    */   
/*    */   public MoveValid(boolean validation, String message)
/*    */   {
/* 21 */     super(415);
/* 22 */     this.validation = validation;
/* 23 */     this.message = message;
/*    */   }
/*    */   
/*    */   public boolean isValidation() {
/* 27 */     return this.validation;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 31 */     return this.message;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 36 */     if (this == o) {
/* 37 */       return true;
/*    */     }
/* 39 */     if (!(o instanceof MoveValid)) {
/* 40 */       return false;
/*    */     }
/* 42 */     MoveValid moveValid = (MoveValid)o;
/* 43 */     return (isValidation() == moveValid.isValidation()) && 
/* 44 */       (Objects.equals(getMessage(), moveValid.getMessage()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\MoveValid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */