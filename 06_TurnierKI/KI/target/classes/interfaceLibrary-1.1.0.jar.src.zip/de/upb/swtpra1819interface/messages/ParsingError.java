/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ public class ParsingError
/*    */   extends Error
/*    */ {
/*    */   public static final int uniqueID = 910;
/*    */   
/*    */   public ParsingError(String message, int causeId)
/*    */   {
/* 13 */     super(910, message, causeId);
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 18 */     if (this == o) {
/* 19 */       return true;
/*    */     }
/* 21 */     if (!(o instanceof ParsingError)) {
/* 22 */       return false;
/*    */     }
/* 24 */     ParsingError that = (ParsingError)o;
/* 25 */     return (Objects.equals(Integer.valueOf(getUniqueId()), Integer.valueOf(that.getUniqueId()))) && 
/* 26 */       (Objects.equals(Integer.valueOf(getCauseId()), Integer.valueOf(that.getCauseId())));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\ParsingError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */