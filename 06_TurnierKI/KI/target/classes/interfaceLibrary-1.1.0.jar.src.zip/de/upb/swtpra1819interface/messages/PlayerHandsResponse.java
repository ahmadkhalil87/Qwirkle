/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.Client;
/*    */ import de.upb.swtpra1819interface.models.Tile;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerHandsResponse
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 426;
/*    */   private Map<Client, ArrayList<Tile>> hands;
/*    */   
/*    */   public PlayerHandsResponse(Map<Client, ArrayList<Tile>> hands)
/*    */   {
/* 24 */     super(426);
/* 25 */     this.hands = hands;
/*    */   }
/*    */   
/*    */   public Map<Client, ArrayList<Tile>> getHands() {
/* 29 */     return this.hands;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 34 */     if (this == o) {
/* 35 */       return true;
/*    */     }
/* 37 */     if (!(o instanceof PlayerHandsResponse)) {
/* 38 */       return false;
/*    */     }
/* 40 */     PlayerHandsResponse that = (PlayerHandsResponse)o;
/* 41 */     return Objects.equals(getHands(), that.getHands());
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\PlayerHandsResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */