/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.Tile;
/*    */ import java.util.Collection;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SendTiles
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 410;
/*    */   private Collection<Tile> tiles;
/*    */   
/*    */   public SendTiles(Collection<Tile> tiles)
/*    */   {
/* 21 */     super(410);
/* 22 */     this.tiles = tiles;
/*    */   }
/*    */   
/*    */   public Collection<Tile> getTiles() {
/* 26 */     return this.tiles;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 31 */     if (this == o) {
/* 32 */       return true;
/*    */     }
/* 34 */     if (!(o instanceof SendTiles)) {
/* 35 */       return false;
/*    */     }
/* 37 */     SendTiles sendTiles = (SendTiles)o;
/* 38 */     return Objects.equals(getTiles(), sendTiles.getTiles());
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\SendTiles.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */