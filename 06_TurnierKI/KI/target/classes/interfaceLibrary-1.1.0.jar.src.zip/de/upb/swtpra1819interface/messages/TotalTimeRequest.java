/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ public class TotalTimeRequest
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 421;
/*    */   
/*    */   public TotalTimeRequest()
/*    */   {
/* 13 */     super(421);
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 18 */     if (this == o) {
/* 19 */       return true;
/*    */     }
/* 21 */     if (!(o instanceof TotalTimeRequest)) {
/* 22 */       return false;
/*    */     }
/* 24 */     TotalTimeRequest that = (TotalTimeRequest)o;
/* 25 */     return Objects.equals(Integer.valueOf(getUniqueId()), Integer.valueOf(that.getUniqueId()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\TotalTimeRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */