/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ public class TurnTimeLeftRequest
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 419;
/*    */   
/*    */   public TurnTimeLeftRequest()
/*    */   {
/* 13 */     super(419);
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 18 */     if (this == o) {
/* 19 */       return true;
/*    */     }
/* 21 */     if (!(o instanceof TurnTimeLeftRequest)) {
/* 22 */       return false;
/*    */     }
/* 24 */     TurnTimeLeftRequest that = (TurnTimeLeftRequest)o;
/* 25 */     return Objects.equals(Integer.valueOf(getUniqueId()), Integer.valueOf(that.getUniqueId()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\TurnTimeLeftRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */