/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.TileOnPosition;
/*    */ import java.util.Collection;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Update
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 416;
/*    */   private Collection<TileOnPosition> updates;
/*    */   private int numberTilesInBag;
/*    */   
/*    */   public Update(Collection<TileOnPosition> updates, int numberTilesInBag)
/*    */   {
/* 23 */     super(416);
/* 24 */     this.updates = updates;
/* 25 */     this.numberTilesInBag = numberTilesInBag;
/*    */   }
/*    */   
/*    */   public Collection<TileOnPosition> getUpdates() {
/* 29 */     return this.updates;
/*    */   }
/*    */   
/*    */   public int getNumberTilesInBag() {
/* 33 */     return this.numberTilesInBag;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 38 */     if (this == o) {
/* 39 */       return true;
/*    */     }
/* 41 */     if (!(o instanceof Update)) {
/* 42 */       return false;
/*    */     }
/* 44 */     Update update = (Update)o;
/* 45 */     return (getNumberTilesInBag() == update.getNumberTilesInBag()) && 
/* 46 */       (Objects.equals(getUpdates(), update.getUpdates()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\Update.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */