/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.Client;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Winner
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 407;
/*    */   private Client client;
/*    */   private int score;
/*    */   private Map<Client, Integer> leaderboard;
/*    */   
/*    */   public Winner(Client client, int score, Map<Client, Integer> leaderboard)
/*    */   {
/* 26 */     super(407);
/* 27 */     this.client = client;
/* 28 */     this.score = score;
/* 29 */     this.leaderboard = leaderboard;
/*    */   }
/*    */   
/*    */   public Client getClient() {
/* 33 */     return this.client;
/*    */   }
/*    */   
/*    */   public int getScore() {
/* 37 */     return this.score;
/*    */   }
/*    */   
/*    */   public Map<Client, Integer> getLeaderboard() {
/* 41 */     return this.leaderboard;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 46 */     if (this == o) {
/* 47 */       return true;
/*    */     }
/* 49 */     if (!(o instanceof Winner)) {
/* 50 */       return false;
/*    */     }
/* 52 */     Winner winner = (Winner)o;
/* 53 */     return (getScore() == winner.getScore()) && 
/* 54 */       (Objects.equals(getClient(), winner.getClient())) && 
/* 55 */       (Objects.equals(getLeaderboard(), winner.getLeaderboard()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\Winner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */