/*     */ package de.upb.swtpra1819interface.models;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Configuration
/*     */ {
/*     */   private int colorShapeCount;
/*     */   
/*     */ 
/*     */   private int tileCount;
/*     */   
/*     */ 
/*     */   private int maxHandTiles;
/*     */   
/*     */ 
/*     */   private long turnTime;
/*     */   
/*     */ 
/*     */   private long timeVisualization;
/*     */   
/*     */ 
/*     */   private WrongMove wrongMove;
/*     */   
/*     */ 
/*     */   private int wrongMovePenalty;
/*     */   
/*     */ 
/*     */   private SlowMove slowMove;
/*     */   
/*     */ 
/*     */   private int slowMovePenalty;
/*     */   
/*     */   private int maxPlayerNumber;
/*     */   
/*     */ 
/*     */   public Configuration(int colorShapeCount, int tileCount, int maxHandTiles, long turnTime, long timeVisualization, WrongMove wrongMove, int wrongMovePenalty, SlowMove slowMove, int slowMovePenalty, int maxPlayerNumber)
/*     */   {
/*  38 */     this.colorShapeCount = colorShapeCount;
/*  39 */     this.tileCount = tileCount;
/*  40 */     this.maxHandTiles = maxHandTiles;
/*  41 */     this.turnTime = turnTime;
/*  42 */     this.timeVisualization = timeVisualization;
/*  43 */     this.wrongMove = wrongMove;
/*  44 */     this.wrongMovePenalty = wrongMovePenalty;
/*  45 */     this.slowMove = slowMove;
/*  46 */     this.slowMovePenalty = slowMovePenalty;
/*  47 */     this.maxPlayerNumber = maxPlayerNumber;
/*     */   }
/*     */   
/*     */   public int getColorShapeCount() {
/*  51 */     return this.colorShapeCount;
/*     */   }
/*     */   
/*     */   public int getTileCount() {
/*  55 */     return this.tileCount;
/*     */   }
/*     */   
/*     */   public int getMaxHandTiles() {
/*  59 */     return this.maxHandTiles;
/*     */   }
/*     */   
/*     */   public long getTurnTime() {
/*  63 */     return this.turnTime;
/*     */   }
/*     */   
/*     */   public long getTimeVisualization() {
/*  67 */     return this.timeVisualization;
/*     */   }
/*     */   
/*     */   public WrongMove getWrongMove() {
/*  71 */     return this.wrongMove;
/*     */   }
/*     */   
/*     */   public int getWrongMovePenalty() {
/*  75 */     return this.wrongMovePenalty;
/*     */   }
/*     */   
/*     */   public SlowMove getSlowMove() {
/*  79 */     return this.slowMove;
/*     */   }
/*     */   
/*     */   public int getSlowMovePenalty() {
/*  83 */     return this.slowMovePenalty;
/*     */   }
/*     */   
/*     */   public int getMaxPlayerNumber() {
/*  87 */     return this.maxPlayerNumber;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/*  92 */     if (this == o) {
/*  93 */       return true;
/*     */     }
/*  95 */     if (!(o instanceof Configuration)) {
/*  96 */       return false;
/*     */     }
/*  98 */     Configuration that = (Configuration)o;
/*  99 */     return (getColorShapeCount() == that.getColorShapeCount()) && 
/* 100 */       (getTileCount() == that.getTileCount()) && 
/* 101 */       (getMaxHandTiles() == that.getMaxHandTiles()) && 
/* 102 */       (getTurnTime() == that.getTurnTime()) && 
/* 103 */       (getTimeVisualization() == that.getTimeVisualization()) && 
/* 104 */       (getWrongMovePenalty() == that.getWrongMovePenalty()) && 
/* 105 */       (getSlowMovePenalty() == that.getSlowMovePenalty()) && 
/* 106 */       (getMaxPlayerNumber() == that.getMaxPlayerNumber()) && 
/* 107 */       (getWrongMove() == that.getWrongMove()) && 
/* 108 */       (getSlowMove() == that.getSlowMove());
/*     */   }
/*     */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\models\Configuration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */