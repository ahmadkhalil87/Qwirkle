/*     */ package de.upb.swtpra1819interface.parser;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import de.upb.swtpra1819interface.messages.AbortGame;
/*     */ import de.upb.swtpra1819interface.messages.AccessDenied;
/*     */ import de.upb.swtpra1819interface.messages.BagRequest;
/*     */ import de.upb.swtpra1819interface.messages.BagResponse;
/*     */ import de.upb.swtpra1819interface.messages.ConnectAccepted;
/*     */ import de.upb.swtpra1819interface.messages.ConnectRequest;
/*     */ import de.upb.swtpra1819interface.messages.CurrentPlayer;
/*     */ import de.upb.swtpra1819interface.messages.EndGame;
/*     */ import de.upb.swtpra1819interface.messages.GameDataRequest;
/*     */ import de.upb.swtpra1819interface.messages.GameDataResponse;
/*     */ import de.upb.swtpra1819interface.messages.GameJoinAccepted;
/*     */ import de.upb.swtpra1819interface.messages.GameJoinRequest;
/*     */ import de.upb.swtpra1819interface.messages.GameListRequest;
/*     */ import de.upb.swtpra1819interface.messages.GameListResponse;
/*     */ import de.upb.swtpra1819interface.messages.LeavingPlayer;
/*     */ import de.upb.swtpra1819interface.messages.LeavingRequest;
/*     */ import de.upb.swtpra1819interface.messages.Message;
/*     */ import de.upb.swtpra1819interface.messages.MessageSend;
/*     */ import de.upb.swtpra1819interface.messages.MessageSignal;
/*     */ import de.upb.swtpra1819interface.messages.MoveValid;
/*     */ import de.upb.swtpra1819interface.messages.NotAllowed;
/*     */ import de.upb.swtpra1819interface.messages.ParsingError;
/*     */ import de.upb.swtpra1819interface.messages.PauseGame;
/*     */ import de.upb.swtpra1819interface.messages.PlayTiles;
/*     */ import de.upb.swtpra1819interface.messages.PlayerHandsRequest;
/*     */ import de.upb.swtpra1819interface.messages.PlayerHandsResponse;
/*     */ import de.upb.swtpra1819interface.messages.ResumeGame;
/*     */ import de.upb.swtpra1819interface.messages.ScoreRequest;
/*     */ import de.upb.swtpra1819interface.messages.ScoreResponse;
/*     */ import de.upb.swtpra1819interface.messages.SendTiles;
/*     */ import de.upb.swtpra1819interface.messages.SpectatorJoinAccepted;
/*     */ import de.upb.swtpra1819interface.messages.SpectatorJoinRequest;
/*     */ import de.upb.swtpra1819interface.messages.StartGame;
/*     */ import de.upb.swtpra1819interface.messages.StartTiles;
/*     */ import de.upb.swtpra1819interface.messages.TileSwapRequest;
/*     */ import de.upb.swtpra1819interface.messages.TileSwapResponse;
/*     */ import de.upb.swtpra1819interface.messages.TileSwapValid;
/*     */ import de.upb.swtpra1819interface.messages.TotalTimeRequest;
/*     */ import de.upb.swtpra1819interface.messages.TotalTimeResponse;
/*     */ import de.upb.swtpra1819interface.messages.TurnTimeLeftRequest;
/*     */ import de.upb.swtpra1819interface.messages.TurnTimeLeftResponse;
/*     */ import de.upb.swtpra1819interface.messages.Update;
/*     */ import de.upb.swtpra1819interface.messages.Winner;
/*     */ import de.upb.swtpra1819interface.models.Configuration;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parser
/*     */ {
/*     */   private Gson gson;
/*     */   private Gson gsonPp;
/*     */   
/*     */   public Parser()
/*     */   {
/*  72 */     GsonBuilder builder = new GsonBuilder();
/*  73 */     builder.enableComplexMapKeySerialization();
/*  74 */     this.gson = builder.create();
/*  75 */     builder.setPrettyPrinting();
/*  76 */     this.gsonPp = builder.create();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String serialize(Message message)
/*     */   {
/*  86 */     return this.gson.toJson(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Message deserialize(String jsonString)
/*     */     throws ParsingException
/*     */   {
/*  97 */     JsonParser jp = new JsonParser();
/*  98 */     JsonElement jsonTree = jp.parse(jsonString);
/*  99 */     JsonObject jsonObject = jsonTree.getAsJsonObject();
/* 100 */     int id = 0;
/*     */     try {
/* 102 */       id = jsonObject.get("uniqueId").getAsInt();
/*     */     } catch (NullPointerException e) {
/* 104 */       throw new ParsingException("Given jsonString has no uniqueID", e);
/*     */     }
/* 106 */     Message message = null;
/* 107 */     switch (id)
/*     */     {
/*     */     case 100: 
/* 110 */       message = (Message)this.gson.fromJson(jsonTree, ConnectRequest.class);
/* 111 */       break;
/*     */     case 300: 
/* 113 */       message = (Message)this.gson.fromJson(jsonTree, GameListRequest.class);
/* 114 */       break;
/*     */     case 302: 
/* 116 */       message = (Message)this.gson.fromJson(jsonTree, GameJoinRequest.class);
/* 117 */       break;
/*     */     case 304: 
/* 119 */       message = (Message)this.gson.fromJson(jsonTree, SpectatorJoinRequest.class);
/* 120 */       break;
/*     */     case 306: 
/* 122 */       message = (Message)this.gson.fromJson(jsonTree, MessageSend.class);
/* 123 */       break;
/*     */     case 405: 
/* 125 */       message = (Message)this.gson.fromJson(jsonTree, LeavingRequest.class);
/* 126 */       break;
/*     */     case 411: 
/* 128 */       message = (Message)this.gson.fromJson(jsonTree, TileSwapRequest.class);
/* 129 */       break;
/*     */     case 414: 
/* 131 */       message = (Message)this.gson.fromJson(jsonTree, PlayTiles.class);
/* 132 */       break;
/*     */     case 417: 
/* 134 */       message = (Message)this.gson.fromJson(jsonTree, ScoreRequest.class);
/* 135 */       break;
/*     */     case 419: 
/* 137 */       message = (Message)this.gson.fromJson(jsonTree, TurnTimeLeftRequest.class);
/* 138 */       break;
/*     */     case 421: 
/* 140 */       message = (Message)this.gson.fromJson(jsonTree, TotalTimeRequest.class);
/* 141 */       break;
/*     */     case 423: 
/* 143 */       message = (Message)this.gson.fromJson(jsonTree, BagRequest.class);
/* 144 */       break;
/*     */     case 425: 
/* 146 */       message = (Message)this.gson.fromJson(jsonTree, PlayerHandsRequest.class);
/* 147 */       break;
/*     */     case 498: 
/* 149 */       message = (Message)this.gson.fromJson(jsonTree, GameDataRequest.class);
/* 150 */       break;
/*     */     
/*     */     case 101: 
/* 153 */       message = (Message)this.gson.fromJson(jsonTree, ConnectAccepted.class);
/* 154 */       break;
/*     */     case 301: 
/* 156 */       message = (Message)this.gson.fromJson(jsonTree, GameListResponse.class);
/* 157 */       break;
/*     */     case 303: 
/* 159 */       message = (Message)this.gson.fromJson(jsonTree, GameJoinAccepted.class);
/* 160 */       break;
/*     */     case 305: 
/* 162 */       message = (Message)this.gson.fromJson(jsonTree, SpectatorJoinAccepted.class);
/* 163 */       break;
/*     */     case 307: 
/* 165 */       message = (Message)this.gson.fromJson(jsonTree, MessageSignal.class);
/* 166 */       break;
/*     */     case 400: 
/* 168 */       message = (Message)this.gson.fromJson(jsonTree, StartGame.class);
/* 169 */       break;
/*     */     case 401: 
/* 171 */       message = (Message)this.gson.fromJson(jsonTree, EndGame.class);
/* 172 */       break;
/*     */     case 402: 
/* 174 */       message = (Message)this.gson.fromJson(jsonTree, AbortGame.class);
/* 175 */       break;
/*     */     case 403: 
/* 177 */       message = (Message)this.gson.fromJson(jsonTree, PauseGame.class);
/* 178 */       break;
/*     */     case 404: 
/* 180 */       message = (Message)this.gson.fromJson(jsonTree, ResumeGame.class);
/* 181 */       break;
/*     */     case 406: 
/* 183 */       message = (Message)this.gson.fromJson(jsonTree, LeavingPlayer.class);
/* 184 */       break;
/*     */     case 407: 
/* 186 */       message = (Message)this.gson.fromJson(jsonTree, Winner.class);
/* 187 */       break;
/*     */     case 408: 
/* 189 */       message = (Message)this.gson.fromJson(jsonTree, StartTiles.class);
/* 190 */       break;
/*     */     case 409: 
/* 192 */       message = (Message)this.gson.fromJson(jsonTree, CurrentPlayer.class);
/* 193 */       break;
/*     */     case 410: 
/* 195 */       message = (Message)this.gson.fromJson(jsonTree, SendTiles.class);
/* 196 */       break;
/*     */     case 412: 
/* 198 */       message = (Message)this.gson.fromJson(jsonTree, TileSwapValid.class);
/* 199 */       break;
/*     */     case 413: 
/* 201 */       message = (Message)this.gson.fromJson(jsonTree, TileSwapResponse.class);
/* 202 */       break;
/*     */     case 415: 
/* 204 */       message = (Message)this.gson.fromJson(jsonTree, MoveValid.class);
/* 205 */       break;
/*     */     case 416: 
/* 207 */       message = (Message)this.gson.fromJson(jsonTree, Update.class);
/* 208 */       break;
/*     */     case 418: 
/* 210 */       message = (Message)this.gson.fromJson(jsonTree, ScoreResponse.class);
/* 211 */       break;
/*     */     case 420: 
/* 213 */       message = (Message)this.gson.fromJson(jsonTree, TurnTimeLeftResponse.class);
/* 214 */       break;
/*     */     case 422: 
/* 216 */       message = (Message)this.gson.fromJson(jsonTree, TotalTimeResponse.class);
/* 217 */       break;
/*     */     case 424: 
/* 219 */       message = (Message)this.gson.fromJson(jsonTree, BagResponse.class);
/* 220 */       break;
/*     */     case 426: 
/* 222 */       message = (Message)this.gson.fromJson(jsonTree, PlayerHandsResponse.class);
/* 223 */       break;
/*     */     case 499: 
/* 225 */       message = (Message)this.gson.fromJson(jsonTree, GameDataResponse.class);
/* 226 */       break;
/*     */     case 900: 
/* 228 */       message = (Message)this.gson.fromJson(jsonTree, AccessDenied.class);
/* 229 */       break;
/*     */     case 910: 
/* 231 */       message = (Message)this.gson.fromJson(jsonTree, ParsingError.class);
/* 232 */       break;
/*     */     case 920: 
/* 234 */       message = (Message)this.gson.fromJson(jsonTree, NotAllowed.class);
/* 235 */       break;
/*     */     }
/*     */     
/*     */     
/* 239 */     if (message == null) {
/* 240 */       throw new ParsingException("Could not parse message");
/*     */     }
/* 242 */     return message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Configuration loadConfig(String filePath)
/*     */     throws ParsingException
/*     */   {
/* 253 */     BufferedReader bufferedReader = null;
/*     */     try {
/* 255 */       bufferedReader = new BufferedReader(new FileReader(filePath));
/* 256 */       StringBuilder stringBuilder = new StringBuilder();
/* 257 */       String line = bufferedReader.readLine();
/* 258 */       while (line != null) {
/* 259 */         stringBuilder.append(line);
/* 260 */         stringBuilder.append(System.lineSeparator());
/* 261 */         line = bufferedReader.readLine();
/*     */       }
/* 263 */       String jsonString = stringBuilder.toString();
/* 264 */       Configuration configuration = (Configuration)this.gsonPp.fromJson(jsonString, Configuration.class);
/* 265 */       if (configuration == null) {
/* 266 */         throw new ParsingException("Could not parse file to Configuration");
/*     */       }
/* 268 */       return configuration;
/*     */     } catch (FileNotFoundException e) {
/* 270 */       e.printStackTrace();
/*     */     } catch (IOException e) {
/* 272 */       e.printStackTrace();
/*     */     } finally {
/*     */       try {
/* 275 */         bufferedReader.close();
/*     */       } catch (IOException e) {
/* 277 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 280 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveConfig(Configuration config, String filePath)
/*     */   {
/* 290 */     if (filePath.contains(File.separator)) {
/* 291 */       String[] directories = filePath.split(File.separator);
/* 292 */       for (int i = 0; i < directories.length - 1; i++) {
/* 293 */         StringBuilder currentPath = new StringBuilder();
/* 294 */         for (int j = 0; j < i; j++) {
/* 295 */           currentPath.append(directories[j] + File.separator);
/*     */         }
/* 297 */         String path = currentPath.toString();
/* 298 */         File file = new File(path + directories[i]);
/* 299 */         file.mkdir();
/*     */       }
/*     */     }
/* 302 */     String jsonString = this.gsonPp.toJson(config);
/* 303 */     File file = new File(filePath);
/*     */     try {
/* 305 */       file.createNewFile();
/* 306 */       FileWriter fileWriter = new FileWriter(file);
/* 307 */       fileWriter.write(jsonString);
/* 308 */       fileWriter.close();
/*     */     } catch (FileNotFoundException e) {
/* 310 */       e.printStackTrace();
/*     */     } catch (IOException e) {
/* 312 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\parser\Parser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */