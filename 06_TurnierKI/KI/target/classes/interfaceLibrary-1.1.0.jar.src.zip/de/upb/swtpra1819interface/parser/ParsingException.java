/*    */ package de.upb.swtpra1819interface.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParsingException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */   public ParsingException() {}
/*    */   
/*    */ 
/*    */   public ParsingException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
/*    */   {
/* 17 */     super(message, cause, enableSuppression, writableStackTrace);
/*    */   }
/*    */   
/*    */   public ParsingException(String message, Throwable cause)
/*    */   {
/* 22 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public ParsingException(String message)
/*    */   {
/* 27 */     super(message);
/*    */   }
/*    */   
/*    */   public ParsingException(Throwable cause)
/*    */   {
/* 32 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\parser\ParsingException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */