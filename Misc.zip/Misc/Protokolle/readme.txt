#Ordneraufbau und Aufteilung der Dokumente

Im Ordner Freitags sind die Protokolle der w�chentlichen Pflichmeetings 
(Freitags 9:00 - 11:00) inklusive des Ersatzmeetings f�r den 21.12.18.
Der Ordner Kurztreffen enth�lt die Protokolle der Kurztreffen die meist zweimal die Woche,
Montags und Mittwochs stattfanden.
Die Sprintreviews geh�ren auch zu diesen Protokollen, diese habe ich aber aus 
�bersichtlichkeitsgr�nden in einen separarten Ordner gepackt.
