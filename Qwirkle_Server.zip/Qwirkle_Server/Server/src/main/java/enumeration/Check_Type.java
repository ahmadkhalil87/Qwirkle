package enumeration;

public enum Check_Type{
	Shape,
	Color,
	Unknown
}
