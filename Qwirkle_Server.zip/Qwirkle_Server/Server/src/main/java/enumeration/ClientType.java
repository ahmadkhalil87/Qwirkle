package enumeration;
/**
 * this class is for enumeration of the Player
 * 
 * 
 * @author Houman Mahtabi
 *
 */

public enum ClientType {
	PLAYER,
	SPECTATOR,
	ENGINE_PLAYER

}
