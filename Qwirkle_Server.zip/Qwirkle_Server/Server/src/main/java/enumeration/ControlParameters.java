package enumeration;

public enum ControlParameters {
	Server, // Binds neighborships, if used
	ENGINE; // Does not bind neighborships, if used
}
