package enumeration;

public enum Direction {
	Horizontal,
	Vertical,
	None;
}
