package enumeration;

public enum Neighbor {
	Top,
	Bottom,
	Right,
	Left
}
