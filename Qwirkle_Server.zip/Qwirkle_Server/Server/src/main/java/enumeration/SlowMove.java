package enumeration;

/**
 * this enumeration is for the penalty (SlowMove)
 * 
 * @author houman Mahtabi
 *
 */

public enum SlowMove {
	POINT_LOSS,
	KICK

}
