package enumeration;

/**
 * this enumeration is for the wrong move in GameBoard
 * 
 * @author houman
 *
 */

public enum WrongMove {
	NOTHING,
	POINT_LOSS,
	KICK

}
