package gameboard;

public class NotValidException extends Exception {

}
