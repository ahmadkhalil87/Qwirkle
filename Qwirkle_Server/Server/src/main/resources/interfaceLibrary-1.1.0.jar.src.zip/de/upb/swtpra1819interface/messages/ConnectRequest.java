/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.ClientType;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectRequest
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 100;
/*    */   private String clientName;
/*    */   private ClientType clientType;
/*    */   
/*    */   public ConnectRequest(String clientName, ClientType clientType)
/*    */   {
/* 22 */     super(100);
/* 23 */     this.clientName = clientName;
/* 24 */     this.clientType = clientType;
/*    */   }
/*    */   
/*    */   public String getClientName() {
/* 28 */     return this.clientName;
/*    */   }
/*    */   
/*    */   public ClientType getClientType() {
/* 32 */     return this.clientType;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 37 */     if (this == o) {
/* 38 */       return true;
/*    */     }
/* 40 */     if (!(o instanceof ConnectRequest)) {
/* 41 */       return false;
/*    */     }
/* 43 */     ConnectRequest that = (ConnectRequest)o;
/* 44 */     return (Objects.equals(getClientName(), that.getClientName())) && 
/* 45 */       (getClientType() == that.getClientType());
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\ConnectRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */