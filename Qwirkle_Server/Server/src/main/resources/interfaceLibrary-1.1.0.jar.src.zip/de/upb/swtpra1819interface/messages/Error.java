/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Error
/*    */   extends Message
/*    */ {
/*    */   private String message;
/*    */   
/*    */ 
/*    */ 
/*    */   private int causeId;
/*    */   
/*    */ 
/*    */ 
/*    */   public Error(int uniqueId, String message, int causeId)
/*    */   {
/* 19 */     super(uniqueId);
/* 20 */     this.message = message;
/* 21 */     this.causeId = causeId;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 25 */     return this.message;
/*    */   }
/*    */   
/*    */   public int getCauseId() {
/* 29 */     return this.causeId;
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\Error.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */