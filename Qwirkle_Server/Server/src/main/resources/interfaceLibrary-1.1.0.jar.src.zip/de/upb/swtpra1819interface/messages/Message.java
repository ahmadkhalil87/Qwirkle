/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Message
/*    */ {
/*    */   private final int uniqueId;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Message(int uniqueId)
/*    */   {
/* 16 */     this.uniqueId = uniqueId;
/*    */   }
/*    */   
/*    */   public int getUniqueId() {
/* 20 */     return this.uniqueId;
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\Message.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */