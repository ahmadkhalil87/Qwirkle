/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.Client;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageSignal
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 307;
/*    */   private String message;
/*    */   private Client client;
/*    */   
/*    */   public MessageSignal(String message, Client client)
/*    */   {
/* 22 */     super(307);
/* 23 */     this.message = message;
/* 24 */     this.client = client;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 28 */     return this.message;
/*    */   }
/*    */   
/*    */   public Client getClient() {
/* 32 */     return this.client;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 37 */     if (this == o) {
/* 38 */       return true;
/*    */     }
/* 40 */     if (!(o instanceof MessageSignal)) {
/* 41 */       return false;
/*    */     }
/* 43 */     MessageSignal that = (MessageSignal)o;
/* 44 */     return (Objects.equals(getMessage(), that.getMessage())) && 
/* 45 */       (Objects.equals(getClient(), that.getClient()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\MessageSignal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */