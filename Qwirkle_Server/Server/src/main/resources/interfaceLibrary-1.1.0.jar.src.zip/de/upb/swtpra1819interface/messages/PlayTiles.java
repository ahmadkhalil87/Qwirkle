/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.TileOnPosition;
/*    */ import java.util.Collection;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayTiles
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 414;
/*    */   private Collection<TileOnPosition> tiles;
/*    */   
/*    */   public PlayTiles(Collection<TileOnPosition> tiles)
/*    */   {
/* 21 */     super(414);
/* 22 */     this.tiles = tiles;
/*    */   }
/*    */   
/*    */   public Collection<TileOnPosition> getTiles() {
/* 26 */     return this.tiles;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 31 */     if (this == o) {
/* 32 */       return true;
/*    */     }
/* 34 */     if (!(o instanceof PlayTiles)) {
/* 35 */       return false;
/*    */     }
/* 37 */     PlayTiles playTiles = (PlayTiles)o;
/* 38 */     return Objects.equals(getTiles(), playTiles.getTiles());
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\PlayTiles.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */