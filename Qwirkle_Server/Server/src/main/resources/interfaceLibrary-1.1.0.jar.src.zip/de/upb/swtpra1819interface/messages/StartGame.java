/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ import de.upb.swtpra1819interface.models.Client;
/*    */ import de.upb.swtpra1819interface.models.Configuration;
/*    */ import java.util.Collection;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartGame
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 400;
/*    */   private Configuration config;
/*    */   private Collection<Client> clients;
/*    */   
/*    */   public StartGame(Configuration config, Collection<Client> clients)
/*    */   {
/* 24 */     super(400);
/* 25 */     this.config = config;
/* 26 */     this.clients = clients;
/*    */   }
/*    */   
/*    */   public Configuration getConfig() {
/* 30 */     return this.config;
/*    */   }
/*    */   
/*    */   public Collection<Client> getClients() {
/* 34 */     return this.clients;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 39 */     if (this == o) {
/* 40 */       return true;
/*    */     }
/* 42 */     if (!(o instanceof StartGame)) {
/* 43 */       return false;
/*    */     }
/* 45 */     StartGame startGame = (StartGame)o;
/* 46 */     return (Objects.equals(getConfig(), startGame.getConfig())) && 
/* 47 */       (Objects.equals(getClients(), startGame.getClients()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\StartGame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */