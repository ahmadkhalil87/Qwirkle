/*    */ package de.upb.swtpra1819interface.messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TurnTimeLeftResponse
/*    */   extends Message
/*    */ {
/*    */   public static final int uniqueID = 420;
/*    */   
/*    */ 
/*    */   private long time;
/*    */   
/*    */ 
/*    */ 
/*    */   public TurnTimeLeftResponse(long time)
/*    */   {
/* 17 */     super(420);
/* 18 */     this.time = time;
/*    */   }
/*    */   
/*    */   public long getTime() {
/* 22 */     return this.time;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 27 */     if (this == o) {
/* 28 */       return true;
/*    */     }
/* 30 */     if (!(o instanceof TurnTimeLeftResponse)) {
/* 31 */       return false;
/*    */     }
/* 33 */     TurnTimeLeftResponse that = (TurnTimeLeftResponse)o;
/* 34 */     return getTime() == that.getTime();
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\messages\TurnTimeLeftResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */