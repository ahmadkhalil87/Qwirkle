/*    */ package de.upb.swtpra1819interface.models;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Client
/*    */ {
/*    */   private int clientId;
/*    */   private String clientName;
/*    */   private ClientType clientType;
/*    */   
/*    */   public Client(int clientId, String clientName, ClientType clientType)
/*    */   {
/* 22 */     this.clientId = clientId;
/* 23 */     this.clientName = clientName;
/* 24 */     this.clientType = clientType;
/*    */   }
/*    */   
/*    */   public int getClientId() {
/* 28 */     return this.clientId;
/*    */   }
/*    */   
/*    */   public String getClientName() {
/* 32 */     return this.clientName;
/*    */   }
/*    */   
/*    */   public ClientType getClientType() {
/* 36 */     return this.clientType;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 41 */     if (this == o) {
/* 42 */       return true;
/*    */     }
/* 44 */     if (!(o instanceof Client)) {
/* 45 */       return false;
/*    */     }
/* 47 */     Client client = (Client)o;
/* 48 */     return (getClientId() == client.getClientId()) && 
/* 49 */       (Objects.equals(getClientName(), client.getClientName())) && 
/* 50 */       (getClientType() == client.getClientType());
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 55 */     return Objects.hash(new Object[] { Integer.valueOf(getClientId()), getClientName(), getClientType() });
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\models\Client.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */