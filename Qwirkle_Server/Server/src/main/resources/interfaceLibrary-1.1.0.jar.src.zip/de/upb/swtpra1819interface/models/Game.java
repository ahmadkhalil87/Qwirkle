/*    */ package de.upb.swtpra1819interface.models;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Game
/*    */ {
/*    */   private int gameId;
/*    */   private String gameName;
/*    */   private GameState gameState;
/*    */   private boolean isTournament;
/*    */   private Collection<Client> players;
/*    */   private Configuration config;
/*    */   
/*    */   public Game(int gameId, String gameName, GameState gameState, boolean isTournament, Collection<Client> players, Configuration config)
/*    */   {
/* 32 */     this.gameId = gameId;
/* 33 */     this.gameName = gameName;
/* 34 */     this.gameState = gameState;
/* 35 */     this.isTournament = isTournament;
/* 36 */     this.players = players;
/* 37 */     this.config = config;
/*    */   }
/*    */   
/*    */   public int getGameId()
/*    */   {
/* 42 */     return this.gameId;
/*    */   }
/*    */   
/*    */   public String getGameName() {
/* 46 */     return this.gameName;
/*    */   }
/*    */   
/*    */   public GameState getGameState() {
/* 50 */     return this.gameState;
/*    */   }
/*    */   
/*    */   public boolean isTournament() {
/* 54 */     return this.isTournament;
/*    */   }
/*    */   
/*    */   public Collection<Client> getPlayers() {
/* 58 */     return this.players;
/*    */   }
/*    */   
/*    */   public Configuration getConfig() {
/* 62 */     return this.config;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 67 */     if (this == o) {
/* 68 */       return true;
/*    */     }
/* 70 */     if (!(o instanceof Game)) {
/* 71 */       return false;
/*    */     }
/* 73 */     Game game = (Game)o;
/* 74 */     return (getGameId() == game.getGameId()) && 
/* 75 */       (isTournament() == game.isTournament()) && 
/* 76 */       (Objects.equals(getGameName(), game.getGameName())) && 
/* 77 */       (getGameState() == game.getGameState()) && 
/* 78 */       (Objects.equals(getPlayers(), game.getPlayers())) && 
/* 79 */       (Objects.equals(getConfig(), game.getConfig()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\models\Game.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */