/*    */ package de.upb.swtpra1819interface.models;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Tile
/*    */ {
/*    */   private int color;
/*    */   
/*    */ 
/*    */   private int shape;
/*    */   
/*    */ 
/*    */   private int uniqueId;
/*    */   
/*    */ 
/*    */ 
/*    */   public Tile(int color, int shape, int uniqueId)
/*    */   {
/* 20 */     this.color = color;
/* 21 */     this.shape = shape;
/* 22 */     this.uniqueId = uniqueId;
/*    */   }
/*    */   
/*    */   public int getColor() {
/* 26 */     return this.color;
/*    */   }
/*    */   
/*    */   public int getShape() {
/* 30 */     return this.shape;
/*    */   }
/*    */   
/*    */   public int getUniqueId() {
/* 34 */     return this.uniqueId;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 39 */     if (this == o) {
/* 40 */       return true;
/*    */     }
/* 42 */     if (!(o instanceof Tile)) {
/* 43 */       return false;
/*    */     }
/* 45 */     Tile tile = (Tile)o;
/* 46 */     return (getColor() == tile.getColor()) && 
/* 47 */       (getShape() == tile.getShape()) && 
/* 48 */       (getUniqueId() == tile.getUniqueId());
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\models\Tile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */