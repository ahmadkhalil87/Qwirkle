/*    */ package de.upb.swtpra1819interface.models;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TileOnPosition
/*    */ {
/*    */   private int coordX;
/*    */   private int coordY;
/*    */   private Tile tile;
/*    */   
/*    */   public TileOnPosition(int coordX, int coordY, Tile tile)
/*    */   {
/* 22 */     this.coordX = coordX;
/* 23 */     this.coordY = coordY;
/* 24 */     this.tile = tile;
/*    */   }
/*    */   
/*    */   public int getCoordX() {
/* 28 */     return this.coordX;
/*    */   }
/*    */   
/*    */   public int getCoordY() {
/* 32 */     return this.coordY;
/*    */   }
/*    */   
/*    */   public Tile getTile() {
/* 36 */     return this.tile;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 41 */     if (this == o) {
/* 42 */       return true;
/*    */     }
/* 44 */     if (!(o instanceof TileOnPosition)) {
/* 45 */       return false;
/*    */     }
/* 47 */     TileOnPosition that = (TileOnPosition)o;
/* 48 */     return (getCoordX() == that.getCoordX()) && 
/* 49 */       (getCoordY() == that.getCoordY()) && 
/* 50 */       (Objects.equals(getTile(), that.getTile()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Lukas\Desktop\Github\swtpra06\Misc\interface-develop\Abgabe\v1.1.0\JavaLibrary\interfaceLibrary-1.1.0.jar!\de\upb\swtpra1819interface\models\TileOnPosition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */